import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-follow-ups',
  templateUrl: './all-follow-ups.component.html',
  styleUrls: ['./all-follow-ups.component.scss']
})
export class AllFollowUpsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

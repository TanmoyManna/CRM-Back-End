import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FollowUpsRoutingModule } from './follow-ups-routing.module';
import { AllFollowUpsComponent } from './all-follow-ups/all-follow-ups.component';
import { AddFollowUpsComponent } from './add-follow-ups/add-follow-ups.component';


@NgModule({
  declarations: [
    AllFollowUpsComponent,
    AddFollowUpsComponent,
  ],
  imports: [
    CommonModule,
    FollowUpsRoutingModule
  ]
})
export class FollowUpsModule { }

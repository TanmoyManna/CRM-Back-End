import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DealClosedRoutingModule } from './deal-closed-routing.module';
import { AllDealClosedComponent } from './all-deal-closed/all-deal-closed.component';
import { AddDealClosedComponent } from './add-deal-closed/add-deal-closed.component';


@NgModule({
  declarations: [
    AllDealClosedComponent,
    AddDealClosedComponent
  ],
  imports: [
    CommonModule,
    DealClosedRoutingModule
  ]
})
export class DealClosedModule { }

import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-add-users',
  templateUrl: './add-users.component.html',
  styleUrls: ['./add-users.component.scss']
})
export class AddUsersComponent implements OnInit {
  userForm: FormGroup = new FormGroup({});
  projects: any[] = [];
  constructor(public formBuilder: FormBuilder,
    private router: Router,
    private api: ApiService,) { }

  ngOnInit(): void {
    this.formInit();
    this.getProjects();
  }
  getProjects() {
    this.api.get('v1/projects').subscribe((res: any) =>{
      console.log(res);      
      if (res.status === 200) {
        this.projects = res.body.allProjects;  
        console.log(this.projects);         
      }
    });
  }

  formInit() {
    this.userForm = this.formBuilder.group({
      name: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,6}$/)]),
      password: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[~`!@#$%^&*()-+={[}\]\|\:;"'<,>.\?])[A-Za-z\d~`!@#$%^&*()-+={[}\]\|\:;"'<,>.\?]{8,}$/)]),
      mobileNo: new FormControl('', Validators.required),
      userType: new FormControl('', Validators.required),
      responsibleProject: new FormControl(''),
    });
  }
  generatePassword(){
    var numberChars = "0123456789";
    var upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    var lowerChars = "abcdefghijklmnopqrstuvwxyz";
    var specialChars = "@$!%*?&#";
    var allChars = numberChars + upperChars + lowerChars + specialChars;
    var randPasswordArray = Array(8);
    randPasswordArray[0] = numberChars;
    randPasswordArray[1] = upperChars;
    randPasswordArray[2] = lowerChars;
    randPasswordArray[3] = specialChars;
    randPasswordArray = randPasswordArray.fill(allChars, 4);
    let pass = this.shuffleArray(randPasswordArray.map(function(x) { return x[Math.floor(Math.random() * x.length)] })).join('');

    this.userForm.patchValue({
      password:pass
    })
    this.userForm.controls.password.updateValueAndValidity();
  }
  shuffleArray(array : any) {
    for (var i = array.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var temp = array[i];
      array[i] = array[j];
      array[j] = temp;
    }
    return array;
  }

  createUser() {
    if (this.userForm.valid) {
      let data : any = {
        name: this.userForm.controls.name.value,
        email: this.userForm.controls.email.value,
        mobileNo: this.userForm.controls.mobileNo.value,
        password: this.userForm.controls.password.value,
        userType: this.userForm.controls.userRole.value,
      }
      if(this.userForm.controls.userType.value == 'MANAGER'){
        data['responsibleProject'] = this.userForm.controls.responsibleProject.value;
      }
      this.api.post('v1/auth/signup', data).subscribe((result:any)=>{
        console.log('Submit Data', result);
        if (result.status === 200) {
          this.api.alert(result.massage, 'success');
          this.userForm.reset();
        } else {
          this.api.alert(result.message, 'warning');
        }
      },
      (err) => {
        this.api.alert(err.message, 'error');
      })
    } else {
      this.userForm.markAllAsTouched();
    }
  }
}

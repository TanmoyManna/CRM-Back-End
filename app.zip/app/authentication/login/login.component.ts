import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { StorageService } from '../../services/storage.service';
import { EventService } from '../../services/event.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup = new FormGroup({});

  constructor(public formBuilder: FormBuilder,
    private router: Router,
    private api: ApiService,
    private storage: StorageService,
    private event: EventService) {
    this.loginForm = this.formBuilder.group({
      email: new FormControl('', [Validators.required, Validators.pattern(/^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*(\+[a-zA-Z0-9-]+)?@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*$/)]),
      password: new FormControl('', [Validators.required]),
    });
  }

  ngOnInit(): void {
  }

  login() {
    if (this.loginForm.valid) {
      let data = {
        email: this.loginForm.controls.email.value,
        password: this.loginForm.controls.password.value,
      };
      this.api.post('v1/auth/login', data).subscribe(
        (res: any) => {
          console.log(res);
          if (res.status === 200) {
            this.api.alert("Login succesfully", 'success');
            localStorage.setItem('userData', JSON.stringify(res.body));
            let data = {
              token: res.body.accessToken,
              id: res.body._id,
              name: res.body.name,
              userType: res.body.userType,
            };
            console.log(data);
            this.storage.setUser(data);
            this.event.setLoginEmmit(true);
            this.router.navigate(['/dashboard']);
          } else {
            this.api.alert(res.message, 'warning');
          }
        },
        (err) => {
          this.api.alert(err.message, 'error');
        });
    } else {
      this.loginForm.markAllAsTouched();
      this.api.alert("Please enter the credentials", 'warning');
    }
  }
}

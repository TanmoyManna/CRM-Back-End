import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-deal-closed',
  templateUrl: './add-deal-closed.component.html',
  styleUrls: ['./add-deal-closed.component.scss']
})
export class AddDealClosedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../../material.module';

import { LeadsRoutingModule } from './leads-routing.module';
import { AllLeadsComponent } from './all-leads/all-leads.component';
import { AddLeadsComponent } from './add-leads/add-leads.component';


@NgModule({
  declarations: [
    AllLeadsComponent,
    AddLeadsComponent
  ],
  imports: [
    CommonModule,
    LeadsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule
  ]
})
export class LeadsModule { }

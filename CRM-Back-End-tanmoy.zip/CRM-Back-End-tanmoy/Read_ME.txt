1. Frame Work ==> Express
2. Data Base Handler(ODM tool) ==> Mongoose
3. For Authentication(JWT Token Based) ==>  Json web Token
4. For Hashing of Password(Hashing with Salt) ==> bcrypt.js
5. To Read Json(JSON to JS Objeect and vice versa) ==> Body Parser

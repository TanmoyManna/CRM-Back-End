import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-leads',
  templateUrl: './add-leads.component.html',
  styleUrls: ['./add-leads.component.scss']
})
export class AddLeadsComponent implements OnInit {
  leadForm: FormGroup = new FormGroup({});
  constructor(public formBuilder: FormBuilder,
    private router: Router,
    private api: ApiService,) { }

  ngOnInit(): void {
    this.formInit();
  }

  formInit() {
    this.leadForm = this.formBuilder.group({
      fullName: new FormControl('', Validators.required),
      email: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,6}$/)]),
      mobileNo: new FormControl('', Validators.required),
      leadSource : new FormControl('', Validators.required),
      leadFor : new FormControl('', Validators.required),
      comments: new FormControl('', Validators.required),
    });
  }

  createUser(form: FormGroup) {
    if (this.leadForm.valid) {
      let data: any = {
        fullName: this.leadForm.controls.fullName.value,
        email: this.leadForm.controls.email.value,
        mobileNo: this.leadForm.controls.mobileNo.value,
        leadSource: this.leadForm.controls.userRole.value,
        leadFor: this.leadForm.controls.userRole.value,
        comments: this.leadForm.controls.userRole.value
      }
      if (this.leadForm.controls.userRole.value == 'manager') {
        data['property'] = this.leadForm.controls.property.value;
      }
      this.api.post('wordsmithrealty/api/v1/properties', data).subscribe((result: any) => {
        console.log('Submit Data', result);
        if (result.status === 200) {
          this.api.alert(result.massage, 'success');
          this.leadForm.reset();
        } else {
          this.api.alert(result.message, 'warning');
        }
      },
        (err) => {
          this.api.alert(err.message, 'error');
        })
    } else {
      this.leadForm.markAllAsTouched();
    }
  }
}

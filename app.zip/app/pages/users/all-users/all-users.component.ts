import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
@Component({
  selector: 'app-all-users',
  templateUrl: './all-users.component.html',
  styleUrls: ['./all-users.component.scss']
})
export class AllUsersComponent implements OnInit {
  dataTable = {
    headerRow: ['Name', 'Email', 'Mobile No', 'Role', 'Status', 'Actions'],
    footerRow: ['Name', 'Email', 'Mobile No', 'Role', 'Status', 'Actions'],
  };
  users: any[] = [];
  constructor(private api: ApiService,) { }

  ngOnInit(): void {
    this.getUsers();
  }

  getUsers() {
    this.api.get('v1/users').subscribe((res: any) =>{
      console.log(res);      
      if (res.status === 200) {
        this.users = res.body.allUsers;         
      }
    });
  }
}

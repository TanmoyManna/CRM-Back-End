import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-follow-ups',
  templateUrl: './add-follow-ups.component.html',
  styleUrls: ['./add-follow-ups.component.scss']
})
export class AddFollowUpsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

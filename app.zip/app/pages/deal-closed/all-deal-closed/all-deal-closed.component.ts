import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-deal-closed',
  templateUrl: './all-deal-closed.component.html',
  styleUrls: ['./all-deal-closed.component.scss']
})
export class AllDealClosedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

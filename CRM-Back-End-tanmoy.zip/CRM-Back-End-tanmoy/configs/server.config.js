module.exports = {
    PORT: 8000
}
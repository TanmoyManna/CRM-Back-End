import { Component, OnInit } from '@angular/core';
import { Meta } from '@angular/platform-browser';

import { isPlatformBrowser } from '@angular/common';
import { Inject, PLATFORM_ID } from '@angular/core';
@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss']
})
export class PagesComponent implements OnInit {
  homePageDummyData: any;
  constructor(private MetaService: Meta,
    @Inject(PLATFORM_ID) private platformId: Object) { }

  ngOnInit(): void {
  }

  bindRootData(event: any): void {
    event.homePageDummyData = this.homePageDummyData;
    if (isPlatformBrowser(this.platformId)) { // check if this is runing in browser
      window.scroll({ 
        top: 0, 
        left: 0, 
        behavior: 'smooth' 
      });
    }    
    if (event.constructor.name != 'SeriesProfileSubpageComponent') {
      this.MetaService.updateTag({ property: 'og:title', content: "Luminate+ - Discover the Future of Legal: a streaming platform with premium CLE content to prepare you for the future of legal. Get insights from today's leading GCs and legal innovators." });
      this.MetaService.updateTag({ property: 'og:image', content: "https://admin.luminateplus.com/uploads/images/Luminate_Devices_Mockup-1.jpg" });
      this.MetaService.updateTag({ property: 'og:description', content: "Luminate+ - Discover the Future of Legal A CLE streaming platform with premium content to help lawyers prepare for the future of legal. Get insights from today's leading general counsel, business executives and law firm pioneers and earn CLE credits, too." });


      this.MetaService.updateTag({ property: 'twitter:title', content: "Luminate+ - Discover the Future of Legal: a streaming platform with premium CLE content to prepare you for the future of legal. Get insights from today's leading GCs and legal innovators." });
      this.MetaService.updateTag({ property: 'twitter:image', content: "https://admin.luminateplus.com/uploads/images/Luminate_Devices_Mockup-1.jpg" });
      this.MetaService.updateTag({ property: 'twitter:description', content: "Luminate+ - Discover the Future of Legal A CLE streaming platform with premium content to help lawyers prepare for the future of legal. Get insights from today's leading general counsel, business executives and law firm pioneers and earn CLE credits, too." });
    }
  }
}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../../material.module';

import { CompaniesRoutingModule } from './companies-routing.module';
import { AllCompaniesComponent } from './all-companies/all-companies.component';
import { AddCompaniesComponent } from './add-companies/add-companies.component';


@NgModule({
  declarations: [
    AllCompaniesComponent,
    AddCompaniesComponent
  ],
  imports: [
    CommonModule,
    CompaniesRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule
  ]
})
export class CompaniesModule { }

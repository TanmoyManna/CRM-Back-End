
const file = require("fs");
const fileP = file.promises;
const fileConfig = require("../configs/file.config");
exports.deleteFiles = async (path) => {
    try {
        const filePath = fileConfig.deleteUrl;
        const userResult = [];
        const result = await fileP.unlink(`${filePath}${path}`);
        console.log('Successfully removed file!');
        return result;
    } catch (err) {
        console.log(err);

    }
};
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-site-visits',
  templateUrl: './all-site-visits.component.html',
  styleUrls: ['./all-site-visits.component.scss']
})
export class AllSiteVisitsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

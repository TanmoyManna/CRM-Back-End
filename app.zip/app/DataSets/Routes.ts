export const ROUTES: any = {
    basic: [
        {
            path: '/dashboard',
            title: 'Dashboard',
            type: 'link',
            icontype: 'dashboard'
        }, {
            path: '/components',
            title: 'Components',
            type: 'sub',
            icontype: 'apps',
            collapse: 'components',
            children: [
                { path: 'buttons', title: 'Buttons', ab: 'B' },
                { path: 'grid', title: 'Grid System', ab: 'GS' },
                { path: 'panels', title: 'Panels', ab: 'P' },
                { path: 'sweet-alert', title: 'Sweet Alert', ab: 'SA' },
                { path: 'notifications', title: 'Notifications', ab: 'N' },
                { path: 'icons', title: 'Icons', ab: 'I' },
                { path: 'typography', title: 'Typography', ab: 'T' }
            ]
        }, {
            path: '/forms',
            title: 'Forms',
            type: 'sub',
            icontype: 'content_paste',
            collapse: 'forms',
            children: [
                { path: 'regular', title: 'Regular Forms', ab: 'RF' },
                { path: 'extended', title: 'Extended Forms', ab: 'EF' },
                { path: 'validation', title: 'Validation Forms', ab: 'VF' },
                { path: 'wizard', title: 'Wizard', ab: 'W' }
            ]
        }, {
            path: '/tables',
            title: 'Tables',
            type: 'sub',
            icontype: 'grid_on',
            collapse: 'tables',
            children: [
                { path: 'regular', title: 'Regular Tables', ab: 'RT' },
                { path: 'extended', title: 'Extended Tables', ab: 'ET' },
                { path: 'datatables.net', title: 'Datatables.net', ab: 'DT' }
            ]
        }, {
            path: '/maps',
            title: 'Maps',
            type: 'sub',
            icontype: 'place',
            collapse: 'maps',
            children: [
                { path: 'google', title: 'Google Maps', ab: 'GM' },
                { path: 'fullscreen', title: 'Full Screen Map', ab: 'FSM' },
                { path: 'vector', title: 'Vector Map', ab: 'VM' }
            ]
        }, {
            path: '/widgets',
            title: 'Widgets',
            type: 'link',
            icontype: 'widgets'

        }, {
            path: '/charts',
            title: 'Charts',
            type: 'link',
            icontype: 'timeline'

        }, {
            path: '/calendar',
            title: 'Calendar',
            type: 'link',
            icontype: 'date_range'
        }, {
            path: '/pages',
            title: 'Pages',
            type: 'sub',
            icontype: 'image',
            collapse: 'pages',
            children: [
                { path: 'pricing', title: 'Pricing', ab: 'P' },
                { path: 'timeline', title: 'Timeline Page', ab: 'TP' },
                { path: 'login', title: 'Login Page', ab: 'LP' },
                { path: 'register', title: 'Register Page', ab: 'RP' },
                { path: 'lock', title: 'Lock Screen Page', ab: 'LSP' },
                { path: 'user', title: 'User Page', ab: 'UP' }
            ]
        }, {
            path: '/pages',
            title: 'Pages',
            type: 'sub',
            icontype: 'image',
            collapse: 'pages',
            children: [
                { path: 'pricing', title: 'Pricing', ab: 'P' },
                { path: 'timeline', title: 'Timeline Page', ab: 'TP' },
                { path: 'login', title: 'Login Page', ab: 'LP' },
                { path: 'register', title: 'Register Page', ab: 'RP' },
                { path: 'lock', title: 'Lock Screen Page', ab: 'LSP' },
                { path: 'user', title: 'User Page', ab: 'UP' }
            ]
        }, {
            path: '/pages',
            title: 'Pages',
            type: 'sub',
            icontype: 'image',
            collapse: 'pages',
            children: [
                { path: 'pricing', title: 'Pricing', ab: 'P' },
                { path: 'timeline', title: 'Timeline Page', ab: 'TP' },
                { path: 'login', title: 'Login Page', ab: 'LP' },
                { path: 'register', title: 'Register Page', ab: 'RP' },
                { path: 'lock', title: 'Lock Screen Page', ab: 'LSP' },
                { path: 'user', title: 'User Page', ab: 'UP' }
            ]
        }
    ],
    admin: [
        {
            path: '/dashboard',
            title: 'Dashboard',
            type: 'link',
            icontype: 'dashboard'
        },
        {
            path: 'users',
            title: 'Users',
            type: 'sub',
            icontype: 'corporate_fare',
            collapse: 'Users',
            children: [
                { path: 'add', title: 'Add Users', ab: 'add' },
                { path: 'all', title: 'See Users', ab: 'remove_red_eye' },
            ]
        },
        {
            path: 'projects',
            title: 'Projects',
            type: 'sub',
            icontype: 'corporate_fare',
            collapse: 'projects',
            children: [
                { path: 'add', title: 'Add Projects', ab: 'add' },
                { path: 'all', title: 'See Projects', ab: 'remove_red_eye' },
            ]
        },
        {
            path: 'companies',
            title: 'Companies',
            type: 'sub',
            icontype: 'corporate_fare',
            collapse: 'companies',
            children: [
                { path: 'add', title: 'Add Companies', ab: 'add' },
                { path: 'all', title: 'See Companies', ab: 'remove_red_eye' },
            ]
        },
        {
            path: 'leads',
            title: 'Leads',
            type: 'sub',
            icontype: 'corporate_fare',
            collapse: 'leads',
            children: [
                { path: 'add', title: 'Add Leads', ab: 'add' },
                { path: 'all', title: 'See Leads', ab: 'remove_red_eye' },
            ]
        },
        {
            path: 'follow-up',
            title: 'Follow Ups',
            type: 'sub',
            icontype: 'corporate_fare',
            collapse: 'follow-up',
            children: [
                // {path: 'add', title: 'Add Follow Ups', ab:'add'},
                { path: 'all', title: 'See Follow Ups', ab: 'remove_red_eye' },
            ]
        },
        {
            path: 'site-visit',
            title: 'Site Visits',
            type: 'sub',
            icontype: 'corporate_fare',
            collapse: 'site-visit',
            children: [
                // {path: 'add', title: 'Add Site Visits', ab:'add'},
                { path: 'all', title: 'See Site Visits', ab: 'remove_red_eye' },
            ]
        },
        {
            path: 'deal-closed',
            title: 'Closed Deals',
            type: 'sub',
            icontype: 'corporate_fare',
            collapse: 'deal-closed',
            children: [
                // {path: 'add', title: 'Add Closed Deals', ab:'add'},
                { path: 'all', title: 'See Closed Deals', ab: 'remove_red_eye' },
            ]
        },
    ]
}


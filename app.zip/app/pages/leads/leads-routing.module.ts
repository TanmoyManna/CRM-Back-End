import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AllLeadsComponent } from './all-leads/all-leads.component';
import { AddLeadsComponent } from './add-leads/add-leads.component';

const routes: Routes = [
  {
    path : 'all',
    component : AllLeadsComponent
  },
  {
    path : 'add',
    component : AddLeadsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LeadsRoutingModule { }

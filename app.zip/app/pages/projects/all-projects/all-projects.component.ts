import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
@Component({
  selector: 'app-all-projects',
  templateUrl: './all-projects.component.html',
  styleUrls: ['./all-projects.component.scss']
})
export class AllProjectsComponent implements OnInit {
  dataTable = {
    headerRow: ['Name', 'Address', 'Developer', 'Responsible Person', 'Actions'],
    footerRow: ['Name', 'Address', 'Developer', 'Responsible Person', 'Actions'],
  };
  projects: any[] = [];
  constructor(private api: ApiService) { }

  ngOnInit(): void {
    this.getProjects();
  }

  getProjects() {
    this.api.get('v1/projects').subscribe((res: any) =>{
      console.log(res);      
      if (res.status === 200) {
        this.projects = res.body.allProjects;  
        console.log(this.projects);         
      }
    });
  }

}

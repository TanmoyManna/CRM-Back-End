import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PagesComponent } from './pages.component';
const routes: Routes = [
  {
    path: '',
    component: PagesComponent,
    children: [
      {
        path: 'dashboard',
        loadChildren: () => import('./dashboard/dashboard.module').then(dashboard => dashboard.DashboardModule)
      },
      {
        path: 'projects',
        loadChildren: () => import('./projects/projects.module').then(projects => projects.ProjectsModule)
      },
      {
        path: 'users',
        loadChildren: () => import('./users/users.module').then(users => users.UsersModule)
      },
      {
        path: 'companies',
        loadChildren: () => import('./companies/companies.module').then(companies => companies.CompaniesModule)
      },
      {
        path: 'leads',
        loadChildren: () => import('./leads/leads.module').then(leads => leads.LeadsModule)
      },
      {
        path: 'follow-up',
        loadChildren: () => import('./follow-ups/follow-ups.module').then(followUps => followUps.FollowUpsModule)
      },
      {
        path: 'site-visit',
        loadChildren: () => import('./site-visits/site-visits.module').then(siteVisit => siteVisit.SiteVisitsModule)
      },
      {
        path: 'deal-closed',
        loadChildren: () => import('./deal-closed/deal-closed.module').then(dealClosed => dealClosed.DealClosedModule)
      },
    ]    
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }

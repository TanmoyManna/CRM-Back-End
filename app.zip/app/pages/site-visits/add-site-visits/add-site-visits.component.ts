import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-site-visits',
  templateUrl: './add-site-visits.component.html',
  styleUrls: ['./add-site-visits.component.scss']
})
export class AddSiteVisitsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

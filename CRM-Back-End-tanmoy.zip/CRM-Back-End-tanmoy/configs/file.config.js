module.exports = {
    // For Live
    // renderUrl : 'app/uploads',
    // deleteUrl : './app/uploads/',
    // developerUrl : './app/uploads/developers',
    // propertyUrl : './app/uploads/properties'

    // For Local
    renderUrl : 'uploads',
    deleteUrl : './uploads/',
    companyUrl : './uploads/companies',
    projectUrl : './uploads/projects',
    
}
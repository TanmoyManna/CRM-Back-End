import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
@Component({
  selector: 'app-all-companies',
  templateUrl: './all-companies.component.html',
  styleUrls: ['./all-companies.component.scss']
})
export class AllCompaniesComponent implements OnInit {
  dataTable = {
    headerRow: ['Name', 'Email', 'Owner Name', 'totalUsers', 'currentUsers', 'status', 'Actions'],
    footerRow: ['Name', 'Email', 'Owner Name', 'totalUsers', 'currentUsers', 'status', 'Actions'],
  };
  companies: any[] = [];
  constructor(private api: ApiService,) { }

  ngOnInit(): void {
    this.getCompanies();
  }

  getCompanies() {
    this.api.get('v1/companies').subscribe((res: any) =>{
      console.log(res);      
      if (res.status === 200) {
        this.companies = res.body.allCompanies;  
        console.log(this.companies);         
      }
    });
  }
}

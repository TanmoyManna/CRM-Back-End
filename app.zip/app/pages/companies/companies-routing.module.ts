import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AllCompaniesComponent } from './all-companies/all-companies.component';
import { AddCompaniesComponent } from './add-companies/add-companies.component';
const routes: Routes = [
  {
    path : 'all',
    component : AllCompaniesComponent
  },
  {
    path : 'add',
    component : AddCompaniesComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompaniesRoutingModule { }

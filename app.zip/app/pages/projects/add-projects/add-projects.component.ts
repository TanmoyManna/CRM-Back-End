import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { isEmpty } from 'underscore';
@Component({
  selector: 'app-add-projects',
  templateUrl: './add-projects.component.html',
  styleUrls: ['./add-projects.component.scss']
})
export class AddProjectsComponent implements OnInit {
  propertyForm: FormGroup = new FormGroup({});
  previewUploadedFiles: string = "";
  constructor(public formBuilder: FormBuilder,
    private router: Router,
    private api: ApiService,) { }

  ngOnInit(): void {
    this.formInit();
  }

  formInit() {
    this.propertyForm = this.formBuilder.group({
      propertyName: new FormControl('', Validators.required),
      propertyAddress: new FormControl('', Validators.required),
      developerName: new FormControl('', Validators.required),
      image: new FormControl('', Validators.required),
    });
  }

  createProperty(form: FormGroup) {
    this.BeforeSubmit(form).then((data: any) => {
      console.log(data);
      console.log(form);
      console.log(form.valid);
      if (form.valid) {
        const formData = new FormData();

        formData.append('propertyName', data.propertyName);
        formData.append('propertyAddress', data.propertyAddress);
        formData.append('developerName', data.developerName);
        formData.append(`image`, data.image);

        this.api.postMultiDataWithToken('v1/projects', formData).subscribe((result: any) => {
          console.log('Submit Data', result);

          if (result.status === 200) {
            this.api.alert(result.massage, 'success');
            this.propertyForm.reset();
            this.previewUploadedFiles = "";
          } else {
            this.api.alert(result.message, 'warning');
          }
        },
          (err) => {
            this.api.alert(err, 'error');
          }
        );
      } else {
        form.markAllAsTouched();
      }
    });
  }
  BeforeSubmit(form: FormGroup): Promise<void> {
    return new Promise((resolve) => {
      Object.keys(form.value).forEach((x) => {
        if (
          typeof form.controls[x].value === 'string' &&
          !isEmpty(form.controls[x].value)
        ) {
          form.controls[x].setValue(form.controls[x].value.trim());
        }
      });
      resolve(form.value);
    });
  }


  fileAdded(event: Event) {
    const inputValue = event.target as HTMLInputElement;
    console.log(inputValue.files);
    if (inputValue.files && inputValue.files.length > 0) {
      if (
        inputValue.files[0].type === 'image/jpeg' ||
        inputValue.files[0].type === 'image/png' ||
        inputValue.files[0].type === 'image/jpg'
      ) {
        this.propertyForm.patchValue({
          image: <File>inputValue.files[0]
        });
        const reader = new FileReader();
        reader.readAsDataURL(inputValue.files[0]);
        console.log(inputValue.files[0]);
        reader.onload = () => {
          this.previewUploadedFiles = reader.result as string;
        };
      }
    }
  }
  deleteFiles() {
    this.previewUploadedFiles = "";
    this.propertyForm.patchValue({
      image: ""
    })
  }
}

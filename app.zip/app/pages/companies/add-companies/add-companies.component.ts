import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { isEmpty } from 'underscore';
@Component({
  selector: 'app-add-companies',
  templateUrl: './add-companies.component.html',
  styleUrls: ['./add-companies.component.scss']
})
export class AddCompaniesComponent implements OnInit {
  companyForm: FormGroup = new FormGroup({});
  previewUploadedFiles: string = "";
  constructor(public formBuilder: FormBuilder,
    private router: Router,
    private api: ApiService,) { }

  ngOnInit(): void {
    this.formInit();
  }

  formInit() {
    this.companyForm = this.formBuilder.group({
      companyName: new FormControl('', Validators.required),
      companyEmail: new FormControl('', Validators.required),
      ownerName: new FormControl('', Validators.required),
      totalUsers: new FormControl('', Validators.required),
      image: new FormControl('', Validators.required),
    });
  }

  createCompany(form: FormGroup) {
    this.BeforeSubmit(form).then((data: any) => {
      console.log(data);
      console.log(form);
      console.log(form.valid);
      if (form.valid) {
        const formData = new FormData();

        formData.append('companyName', data.companyName);
        formData.append('companyEmail', data.companyEmail);
        formData.append('ownerName', data.ownerName);
        formData.append('totalUsers', data.totalUsers);
        formData.append(`image`, data.image);

        this.api.postMultiDataWithToken('v1/companies', formData).subscribe((result: any) => {
          console.log('Submit Data', result);

          if (result.status === 200) {
            this.api.alert(result.massage, 'success');
            this.companyForm.reset();
            this.previewUploadedFiles = "";
            //window.location.reload();
          } else {
            this.api.alert(result.message, 'warning');
          }
        },
          (err) => {
            this.api.alert(err, 'error');
          }
        );
      } else {
        form.markAllAsTouched();
      }
    });
  }
  BeforeSubmit(form: FormGroup): Promise<void> {
    return new Promise((resolve) => {
      Object.keys(form.value).forEach((x) => {
        if (
          typeof form.controls[x].value === 'string' &&
          !isEmpty(form.controls[x].value)
        ) {
          form.controls[x].setValue(form.controls[x].value.trim());
        }
      });
      resolve(form.value);
    });
  }

  fileAdded(event: Event) {
    const inputValue = event.target as HTMLInputElement;
    console.log(inputValue.files);
    if (inputValue.files && inputValue.files.length > 0) {
      if (
        inputValue.files[0].type === 'image/jpeg' ||
        inputValue.files[0].type === 'image/png' ||
        inputValue.files[0].type === 'image/jpg'
      ) {
        this.companyForm.patchValue({
          image: <File>inputValue.files[0]
        });
        const reader = new FileReader();
        reader.readAsDataURL(inputValue.files[0]);
        console.log(inputValue.files[0]);
        reader.onload = () => {
          this.previewUploadedFiles = reader.result as string;
        };
      }
    }
  }
  deleteFiles() {
    this.previewUploadedFiles = "";
    this.companyForm.patchValue({
      image: ""
    })
  }
  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (
      charCode > 46 &&
      (charCode < 48 || charCode > 57) &&
      (charCode < 96 || charCode > 105)
    ) {
      return false;
    }
    return true;
  }
}

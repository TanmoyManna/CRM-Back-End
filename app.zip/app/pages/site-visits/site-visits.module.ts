import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SiteVisitsRoutingModule } from './site-visits-routing.module';
import { AddSiteVisitsComponent } from './add-site-visits/add-site-visits.component';
import { AllSiteVisitsComponent } from './all-site-visits/all-site-visits.component';


@NgModule({
  declarations: [
    AddSiteVisitsComponent,
    AllSiteVisitsComponent
  ],
  imports: [
    CommonModule,
    SiteVisitsRoutingModule
  ]
})
export class SiteVisitsModule { }

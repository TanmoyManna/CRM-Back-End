import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AllDealClosedComponent } from './all-deal-closed/all-deal-closed.component';
import { AddDealClosedComponent } from './add-deal-closed/add-deal-closed.component';

const routes: Routes = [
  {
    path : 'all',
    component : AllDealClosedComponent
  },
  {
    path : 'add',
    component : AddDealClosedComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DealClosedRoutingModule { }

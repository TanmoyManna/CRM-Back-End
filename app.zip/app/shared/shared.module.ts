import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router';
import { MaterialModule } from '../material.module';

import { SidebarComponentComponent } from './sidebar-component/sidebar-component.component';
import { NavbarComponent } from './navbar/navbar.component';


@NgModule({
  declarations: [
    SidebarComponentComponent,
    NavbarComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule
  ],
  exports: [
    SidebarComponentComponent,
    NavbarComponent
  ]
})
export class SharedModule { }

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AllFollowUpsComponent } from './all-follow-ups/all-follow-ups.component';
import { AddFollowUpsComponent } from './add-follow-ups/add-follow-ups.component';

const routes: Routes = [
  {
    path : 'all',
    component : AllFollowUpsComponent
  },
  {
    path : 'add',
    component : AddFollowUpsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FollowUpsRoutingModule { }

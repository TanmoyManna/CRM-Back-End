import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddSiteVisitsComponent } from './add-site-visits/add-site-visits.component';
import { AllSiteVisitsComponent } from './all-site-visits/all-site-visits.component';

const routes: Routes = [
  {
    path : 'all',
    component : AllSiteVisitsComponent
  },
  {
    path : 'add',
    component : AddSiteVisitsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SiteVisitsRoutingModule { }

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-leads',
  templateUrl: './all-leads.component.html',
  styleUrls: ['./all-leads.component.scss']
})
export class AllLeadsComponent implements OnInit {
  dataTable = {
    headerRow: ['Name', 'Email', 'Mobile No', 'Lead Source', 'Lead For', 'Actions'],
    footerRow: ['Name', 'Email', 'Mobile No', 'Lead Source', 'Lead For', 'Actions'],

    DataSet: ['Tanmoy', 'tanmoy@gmail.com', '7003847181', 'emails', 'test1']
  };

  constructor() { }

  ngOnInit(): void {
  }

}

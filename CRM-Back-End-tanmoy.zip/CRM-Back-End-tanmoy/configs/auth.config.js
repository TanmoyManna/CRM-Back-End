module.exports = {
    secret : "BatMan is stronger than SuperMan"
}